import { useState } from 'react';
import { AlertTriangle, Users } from 'lucide-react';
import CameraCapture from './components/CameraCapture';
import EmergencyForm from './components/EmergencyForm';
import ResponseDashboard from './components/ResponseDashboard';
import { EmergencyRequest, LocationData } from './types';

type AppMode = 'select' | 'volunteer' | 'responder';
type VolunteerStep = 'camera' | 'form' | 'success';

function App() {
  const [mode, setMode] = useState<AppMode>('select');
  const [volunteerStep, setVolunteerStep] = useState<VolunteerStep>('camera');
  const [capturedPhoto, setCapturedPhoto] = useState<string>('');
  const [capturedLocation, setCapturedLocation] = useState<LocationData | null>(null);
  const [emergencyRequests, setEmergencyRequests] = useState<EmergencyRequest[]>([]);
  const [error, setError] = useState<string>('');

  const handlePhotoCapture = (photoData: string, location: LocationData) => {
    setCapturedPhoto(photoData);
    setCapturedLocation(location);
    setVolunteerStep('form');
  };

  const handleFormSubmit = (request: Omit<EmergencyRequest, 'id' | 'createdAt' | 'updatedAt' | 'status'>) => {
    const newRequest: EmergencyRequest = {
      ...request,
      id: crypto.randomUUID(),
      status: 'pending',
      createdAt: new Date(),
      updatedAt: new Date()
    };

    setEmergencyRequests(prev => [newRequest, ...prev]);
    setVolunteerStep('success');

    setTimeout(() => {
      setVolunteerStep('camera');
      setCapturedPhoto('');
      setCapturedLocation(null);
    }, 3000);
  };

  const handleFormCancel = () => {
    setVolunteerStep('camera');
    setCapturedPhoto('');
    setCapturedLocation(null);
  };

  const handleUpdateStatus = (id: string, status: EmergencyRequest['status']) => {
    setEmergencyRequests(prev =>
      prev.map(req =>
        req.id === id
          ? { ...req, status, updatedAt: new Date(), responseTime: status === 'in_progress' ? new Date() : req.responseTime }
          : req
      )
    );
  };

  const handleError = (errorMessage: string) => {
    setError(errorMessage);
    setTimeout(() => setError(''), 5000);
  };

  if (mode === 'select') {
    return (
      <div className="min-h-screen bg-gradient-to-br from-red-600 via-orange-600 to-red-700 flex items-center justify-center p-4">
        <div className="max-w-4xl w-full">
          <div className="text-center mb-12">
            <div className="flex items-center justify-center gap-3 mb-4">
              <AlertTriangle className="w-16 h-16 text-white" />
              <h1 className="text-6xl font-bold text-white">ResQVision</h1>
            </div>
            <p className="text-xl text-white text-opacity-90 max-w-2xl mx-auto">
              Rapid disaster response system connecting victims with help through intelligent location tracking
            </p>
          </div>

          <div className="grid md:grid-cols-2 gap-6">
            <button
              onClick={() => setMode('volunteer')}
              className="bg-white hover:bg-gray-50 rounded-2xl p-8 transition-all hover:scale-105 shadow-2xl group"
            >
              <div className="bg-red-100 w-20 h-20 rounded-full flex items-center justify-center mx-auto mb-4 group-hover:bg-red-200 transition-colors">
                <AlertTriangle className="w-10 h-10 text-red-600" />
              </div>
              <h2 className="text-2xl font-bold text-gray-900 mb-3">Volunteer Mode</h2>
              <p className="text-gray-600">
                Report emergencies with live camera and location tracking. Quick capture to dispatch help immediately.
              </p>
              <div className="mt-6 bg-red-50 rounded-lg p-4 text-left">
                <p className="text-sm font-semibold text-red-900 mb-2">Features:</p>
                <ul className="text-sm text-red-800 space-y-1">
                  <li>• Live camera with GPS embedding</li>
                  <li>• Urgency level classification</li>
                  <li>• Instant help request submission</li>
                </ul>
              </div>
            </button>

            <button
              onClick={() => setMode('responder')}
              className="bg-white hover:bg-gray-50 rounded-2xl p-8 transition-all hover:scale-105 shadow-2xl group"
            >
              <div className="bg-blue-100 w-20 h-20 rounded-full flex items-center justify-center mx-auto mb-4 group-hover:bg-blue-200 transition-colors">
                <Users className="w-10 h-10 text-blue-600" />
              </div>
              <h2 className="text-2xl font-bold text-gray-900 mb-3">Response Team</h2>
              <p className="text-gray-600">
                View all emergency requests sorted by urgency and distance. Navigate to victims and manage responses.
              </p>
              <div className="mt-6 bg-blue-50 rounded-lg p-4 text-left">
                <p className="text-sm font-semibold text-blue-900 mb-2">Features:</p>
                <ul className="text-sm text-blue-800 space-y-1">
                  <li>• Real-time emergency dashboard</li>
                  <li>• Distance-based prioritization</li>
                  <li>• Direct navigation to victims</li>
                </ul>
              </div>
            </button>
          </div>

          <div className="mt-8 text-center text-white text-opacity-75 text-sm">
            <p>Powered by GPS location tracking and intelligent routing</p>
            <p className="mt-1">Every second counts. Every life matters.</p>
          </div>
        </div>
      </div>
    );
  }

  if (mode === 'volunteer') {
    return (
      <div className="min-h-screen bg-gray-900">
        {error && (
          <div className="fixed top-4 left-1/2 transform -translate-x-1/2 bg-red-600 text-white px-6 py-3 rounded-lg shadow-lg z-50 max-w-md">
            {error}
          </div>
        )}

        {volunteerStep === 'camera' && (
          <div className="h-screen flex flex-col">
            <div className="bg-red-600 text-white px-6 py-4 flex items-center justify-between">
              <div className="flex items-center gap-3">
                <AlertTriangle className="w-6 h-6" />
                <h1 className="text-xl font-bold">ResQVision - Report Emergency</h1>
              </div>
              <button
                onClick={() => setMode('select')}
                className="bg-white bg-opacity-20 hover:bg-opacity-30 px-4 py-2 rounded-lg text-sm transition-colors"
              >
                Back
              </button>
            </div>
            <div className="flex-1">
              <CameraCapture onCapture={handlePhotoCapture} onError={handleError} />
            </div>
          </div>
        )}

        {volunteerStep === 'form' && capturedLocation && (
          <div className="min-h-screen flex items-center justify-center p-4">
            <EmergencyForm
              photoData={capturedPhoto}
              location={capturedLocation}
              onSubmit={handleFormSubmit}
              onCancel={handleFormCancel}
            />
          </div>
        )}

        {volunteerStep === 'success' && (
          <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-green-600 to-green-700 p-4">
            <div className="bg-white rounded-2xl p-12 max-w-md w-full text-center shadow-2xl">
              <div className="bg-green-100 w-20 h-20 rounded-full flex items-center justify-center mx-auto mb-6">
                <svg className="w-10 h-10 text-green-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={3} d="M5 13l4 4L19 7" />
                </svg>
              </div>
              <h2 className="text-3xl font-bold text-gray-900 mb-4">Request Submitted!</h2>
              <p className="text-gray-600 mb-2">Help is on the way</p>
              <p className="text-sm text-gray-500">Response teams have been notified</p>
              <div className="mt-8 animate-pulse text-gray-400 text-sm">
                Returning to camera...
              </div>
            </div>
          </div>
        )}
      </div>
    );
  }

  if (mode === 'responder') {
    return (
      <ResponseDashboard
        requests={emergencyRequests}
        onUpdateStatus={handleUpdateStatus}
        onBack={() => setMode('select')}
      />
    );
  }

  return null;
}

export default App;

import { useState, useRef, useEffect } from 'react';
import { Camera, MapPin, Loader2 } from 'lucide-react';
import { LocationData } from '../types';

interface CameraCaptureProps {
  onCapture: (photoData: string, location: LocationData) => void;
  onError: (error: string) => void;
}

export default function CameraCapture({ onCapture, onError }: CameraCaptureProps) {
  const [isStreaming, setIsStreaming] = useState(false);
  const [isCapturing, setIsCapturing] = useState(false);
  const [locationStatus, setLocationStatus] = useState<string>('');
  const videoRef = useRef<HTMLVideoElement>(null);
  const streamRef = useRef<MediaStream | null>(null);

  useEffect(() => {
    startCamera();
    return () => {
      stopCamera();
    };
  }, []);

  const startCamera = async () => {
    try {
      const stream = await navigator.mediaDevices.getUserMedia({
        video: { facingMode: 'environment', width: { ideal: 1920 }, height: { ideal: 1080 } },
        audio: false
      });

      if (videoRef.current) {
        videoRef.current.srcObject = stream;
        streamRef.current = stream;
        setIsStreaming(true);
      }
    } catch (err) {
      onError('Camera access denied. Please enable camera permissions.');
      console.error('Camera error:', err);
    }
  };

  const stopCamera = () => {
    if (streamRef.current) {
      streamRef.current.getTracks().forEach(track => track.stop());
      streamRef.current = null;
    }
    setIsStreaming(false);
  };

  const getLocation = (): Promise<LocationData> => {
    return new Promise((resolve, reject) => {
      if (!navigator.geolocation) {
        reject(new Error('Geolocation not supported'));
        return;
      }

      setLocationStatus('Getting location...');

      navigator.geolocation.getCurrentPosition(
        async (position) => {
          const { latitude, longitude, accuracy } = position.coords;

          try {
            const response = await fetch(
              `https://nominatim.openstreetmap.org/reverse?format=json&lat=${latitude}&lon=${longitude}`
            );
            const data = await response.json();

            resolve({
              latitude,
              longitude,
              accuracy,
              address: data.display_name || `${latitude.toFixed(6)}, ${longitude.toFixed(6)}`
            });
            setLocationStatus('');
          } catch {
            resolve({
              latitude,
              longitude,
              accuracy,
              address: `${latitude.toFixed(6)}, ${longitude.toFixed(6)}`
            });
            setLocationStatus('');
          }
        },
        (error) => {
          setLocationStatus('');
          reject(new Error(`Location error: ${error.message}`));
        },
        { enableHighAccuracy: true, timeout: 10000, maximumAge: 0 }
      );
    });
  };

  const capturePhoto = async () => {
    if (!videoRef.current || isCapturing) return;

    setIsCapturing(true);

    try {
      const location = await getLocation();

      const canvas = document.createElement('canvas');
      canvas.width = videoRef.current.videoWidth;
      canvas.height = videoRef.current.videoHeight;
      const ctx = canvas.getContext('2d');

      if (ctx) {
        ctx.drawImage(videoRef.current, 0, 0);

        ctx.fillStyle = 'rgba(0, 0, 0, 0.7)';
        ctx.fillRect(10, canvas.height - 100, canvas.width - 20, 90);

        ctx.fillStyle = '#fff';
        ctx.font = 'bold 20px Arial';
        ctx.fillText(`📍 Location: ${location.latitude.toFixed(6)}, ${location.longitude.toFixed(6)}`, 20, canvas.height - 70);
        ctx.fillText(`⏰ ${new Date().toLocaleString()}`, 20, canvas.height - 40);
        ctx.font = '16px Arial';
        ctx.fillText(`Accuracy: ±${location.accuracy.toFixed(0)}m`, 20, canvas.height - 15);

        const photoData = canvas.toDataURL('image/jpeg', 0.95);
        onCapture(photoData, location);
      }
    } catch (err) {
      onError(err instanceof Error ? err.message : 'Failed to capture photo and location');
    } finally {
      setIsCapturing(false);
    }
  };

  return (
    <div className="relative w-full h-full bg-black rounded-lg overflow-hidden">
      <video
        ref={videoRef}
        autoPlay
        playsInline
        muted
        className="w-full h-full object-cover"
      />

      {!isStreaming && (
        <div className="absolute inset-0 flex items-center justify-center bg-black bg-opacity-75">
          <div className="text-center text-white">
            <Camera className="w-16 h-16 mx-auto mb-4 opacity-50" />
            <p>Initializing camera...</p>
          </div>
        </div>
      )}

      {locationStatus && (
        <div className="absolute top-4 left-4 right-4 bg-black bg-opacity-75 text-white px-4 py-2 rounded-lg flex items-center gap-2">
          <Loader2 className="w-5 h-5 animate-spin" />
          <span>{locationStatus}</span>
        </div>
      )}

      <div className="absolute bottom-0 left-0 right-0 p-6 bg-gradient-to-t from-black to-transparent">
        <button
          onClick={capturePhoto}
          disabled={!isStreaming || isCapturing}
          className="w-full bg-red-600 hover:bg-red-700 disabled:bg-gray-600 text-white font-bold py-4 px-6 rounded-lg flex items-center justify-center gap-3 transition-colors text-lg shadow-lg"
        >
          {isCapturing ? (
            <>
              <Loader2 className="w-6 h-6 animate-spin" />
              Capturing...
            </>
          ) : (
            <>
              <Camera className="w-6 h-6" />
              Capture Location & Photo
            </>
          )}
        </button>

        <div className="mt-3 flex items-center justify-center gap-2 text-white text-sm">
          <MapPin className="w-4 h-4" />
          <span>GPS location will be embedded in photo</span>
        </div>
      </div>
    </div>
  );
}

import { useState, useEffect } from 'react';
import { MapPin, Clock, AlertTriangle, CheckCircle, Navigation, Phone, Filter } from 'lucide-react';
import { EmergencyRequest, UrgencyLevel, HelpType } from '../types';

interface ResponseDashboardProps {
  requests: EmergencyRequest[];
  onUpdateStatus: (id: string, status: EmergencyRequest['status']) => void;
  onBack: () => void;
}

export default function ResponseDashboard({ requests, onUpdateStatus, onBack }: ResponseDashboardProps) {
  const [currentLocation, setCurrentLocation] = useState<{ lat: number; lng: number } | null>(null);
  const [filterUrgency, setFilterUrgency] = useState<UrgencyLevel | 'all'>('all');
  const [filterHelpType, setFilterHelpType] = useState<HelpType | 'all'>('all');
  const [filterStatus, setFilterStatus] = useState<'all' | 'pending' | 'in_progress' | 'completed'>('pending');

  useEffect(() => {
    if (navigator.geolocation) {
      navigator.geolocation.getCurrentPosition(
        (position) => {
          setCurrentLocation({
            lat: position.coords.latitude,
            lng: position.coords.longitude
          });
        },
        (error) => console.error('Location error:', error)
      );
    }
  }, []);

  const calculateDistance = (lat1: number, lon1: number, lat2: number, lon2: number): number => {
    const R = 6371;
    const dLat = (lat2 - lat1) * Math.PI / 180;
    const dLon = (lon2 - lon1) * Math.PI / 180;
    const a =
      Math.sin(dLat / 2) * Math.sin(dLat / 2) +
      Math.cos(lat1 * Math.PI / 180) * Math.cos(lat2 * Math.PI / 180) *
      Math.sin(dLon / 2) * Math.sin(dLon / 2);
    const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
    return R * c;
  };

  const filteredAndSortedRequests = requests
    .filter(req => {
      if (filterUrgency !== 'all' && req.urgencyLevel !== filterUrgency) return false;
      if (filterHelpType !== 'all' && req.helpType !== filterHelpType) return false;
      if (filterStatus !== 'all' && req.status !== filterStatus) return false;
      return true;
    })
    .map(req => ({
      ...req,
      distance: currentLocation
        ? calculateDistance(currentLocation.lat, currentLocation.lng, req.latitude, req.longitude)
        : undefined
    }))
    .sort((a, b) => {
      const urgencyOrder = { urgent: 0, moderate: 1, low: 2 };
      if (a.urgencyLevel !== b.urgencyLevel) {
        return urgencyOrder[a.urgencyLevel] - urgencyOrder[b.urgencyLevel];
      }
      if (a.distance !== undefined && b.distance !== undefined) {
        return a.distance - b.distance;
      }
      return new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime();
    });

  const getUrgencyColor = (urgency: UrgencyLevel) => {
    switch (urgency) {
      case 'urgent': return 'bg-red-100 text-red-800 border-red-300';
      case 'moderate': return 'bg-orange-100 text-orange-800 border-orange-300';
      case 'low': return 'bg-yellow-100 text-yellow-800 border-yellow-300';
    }
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'pending': return 'bg-gray-100 text-gray-800';
      case 'in_progress': return 'bg-blue-100 text-blue-800';
      case 'completed': return 'bg-green-100 text-green-800';
      default: return 'bg-gray-100 text-gray-800';
    }
  };

  const getHelpTypeLabel = (type: HelpType) => {
    const labels: Record<HelpType, string> = {
      medical: 'Medical',
      rescue: 'Rescue',
      supplies: 'Supplies',
      body_recovery: 'Body Recovery',
      shelter: 'Shelter',
      evacuation: 'Evacuation'
    };
    return labels[type];
  };

  const openInMaps = (lat: number, lng: number) => {
    window.open(`https://www.google.com/maps/dir/?api=1&destination=${lat},${lng}`, '_blank');
  };

  const stats = {
    total: requests.length,
    pending: requests.filter(r => r.status === 'pending').length,
    inProgress: requests.filter(r => r.status === 'in_progress').length,
    urgent: requests.filter(r => r.urgencyLevel === 'urgent' && r.status !== 'completed').length
  };

  return (
    <div className="min-h-screen bg-gray-50">
      <div className="bg-gradient-to-r from-blue-600 to-blue-700 text-white px-6 py-6 shadow-lg">
        <div className="max-w-7xl mx-auto">
          <div className="flex items-center justify-between mb-4">
            <h1 className="text-3xl font-bold">Response Team Dashboard</h1>
            <button
              onClick={onBack}
              className="bg-white bg-opacity-20 hover:bg-opacity-30 px-4 py-2 rounded-lg transition-colors"
            >
              Switch to Volunteer Mode
            </button>
          </div>

          <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
            <div className="bg-white bg-opacity-10 rounded-lg p-4">
              <div className="text-3xl font-bold">{stats.total}</div>
              <div className="text-sm text-blue-100">Total Requests</div>
            </div>
            <div className="bg-white bg-opacity-10 rounded-lg p-4">
              <div className="text-3xl font-bold">{stats.pending}</div>
              <div className="text-sm text-blue-100">Pending</div>
            </div>
            <div className="bg-white bg-opacity-10 rounded-lg p-4">
              <div className="text-3xl font-bold">{stats.inProgress}</div>
              <div className="text-sm text-blue-100">In Progress</div>
            </div>
            <div className="bg-red-500 bg-opacity-80 rounded-lg p-4">
              <div className="text-3xl font-bold">{stats.urgent}</div>
              <div className="text-sm">Urgent Cases</div>
            </div>
          </div>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-6 py-6">
        <div className="bg-white rounded-lg shadow-md p-4 mb-6">
          <div className="flex items-center gap-2 mb-3">
            <Filter className="w-5 h-5 text-gray-600" />
            <h3 className="font-semibold text-gray-700">Filters</h3>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div>
              <label className="block text-sm font-medium text-gray-600 mb-1">Status</label>
              <select
                value={filterStatus}
                onChange={(e) => setFilterStatus(e.target.value as any)}
                className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 outline-none"
              >
                <option value="all">All Statuses</option>
                <option value="pending">Pending</option>
                <option value="in_progress">In Progress</option>
                <option value="completed">Completed</option>
              </select>
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-600 mb-1">Urgency</label>
              <select
                value={filterUrgency}
                onChange={(e) => setFilterUrgency(e.target.value as any)}
                className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 outline-none"
              >
                <option value="all">All Urgencies</option>
                <option value="urgent">Urgent</option>
                <option value="moderate">Moderate</option>
                <option value="low">Low</option>
              </select>
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-600 mb-1">Help Type</label>
              <select
                value={filterHelpType}
                onChange={(e) => setFilterHelpType(e.target.value as any)}
                className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 outline-none"
              >
                <option value="all">All Types</option>
                <option value="medical">Medical</option>
                <option value="rescue">Rescue</option>
                <option value="supplies">Supplies</option>
                <option value="shelter">Shelter</option>
                <option value="evacuation">Evacuation</option>
                <option value="body_recovery">Body Recovery</option>
              </select>
            </div>
          </div>
        </div>

        <div className="space-y-4">
          {filteredAndSortedRequests.length === 0 ? (
            <div className="bg-white rounded-lg shadow-md p-12 text-center">
              <CheckCircle className="w-16 h-16 text-gray-300 mx-auto mb-4" />
              <p className="text-gray-500 text-lg">No emergency requests match your filters</p>
            </div>
          ) : (
            filteredAndSortedRequests.map((request) => (
              <div key={request.id} className="bg-white rounded-lg shadow-md hover:shadow-lg transition-shadow">
                <div className="p-6">
                  <div className="flex flex-wrap gap-3 mb-4">
                    <span className={`px-3 py-1 rounded-full text-xs font-bold border-2 ${getUrgencyColor(request.urgencyLevel)}`}>
                      {request.urgencyLevel.toUpperCase()}
                    </span>
                    <span className={`px-3 py-1 rounded-full text-xs font-semibold ${getStatusColor(request.status)}`}>
                      {request.status.replace('_', ' ').toUpperCase()}
                    </span>
                    <span className="px-3 py-1 rounded-full text-xs font-semibold bg-blue-100 text-blue-800">
                      {getHelpTypeLabel(request.helpType)}
                    </span>
                    {request.distance !== undefined && (
                      <span className="px-3 py-1 rounded-full text-xs font-semibold bg-green-100 text-green-800">
                        {request.distance.toFixed(1)} km away
                      </span>
                    )}
                  </div>

                  <div className="grid md:grid-cols-3 gap-6">
                    {request.photoUrl && (
                      <div className="md:col-span-1">
                        <img src={request.photoUrl} alt="Location" className="w-full rounded-lg border-2 border-gray-200" />
                      </div>
                    )}

                    <div className={request.photoUrl ? 'md:col-span-2' : 'md:col-span-3'}>
                      <div className="space-y-3">
                        <div className="flex items-start gap-2">
                          <MapPin className="w-5 h-5 text-red-500 flex-shrink-0 mt-1" />
                          <div>
                            <div className="font-mono text-sm text-gray-700">
                              {request.latitude.toFixed(6)}, {request.longitude.toFixed(6)}
                            </div>
                            {request.locationAddress && (
                              <div className="text-sm text-gray-600 mt-1">{request.locationAddress}</div>
                            )}
                          </div>
                        </div>

                        <div className="flex items-center gap-2 text-sm text-gray-600">
                          <Clock className="w-4 h-4" />
                          <span>Reported: {new Date(request.createdAt).toLocaleString()}</span>
                        </div>

                        {request.volunteerContact && (
                          <div className="flex items-center gap-2 text-sm text-gray-600">
                            <Phone className="w-4 h-4" />
                            <span>Contact: {request.volunteerContact}</span>
                          </div>
                        )}

                        {request.description && (
                          <div className="bg-gray-50 p-3 rounded-lg">
                            <p className="text-sm text-gray-700">{request.description}</p>
                          </div>
                        )}

                        <div className="flex flex-wrap gap-2 pt-2">
                          <button
                            onClick={() => openInMaps(request.latitude, request.longitude)}
                            className="flex items-center gap-2 bg-blue-600 hover:bg-blue-700 text-white px-4 py-2 rounded-lg text-sm font-semibold transition-colors"
                          >
                            <Navigation className="w-4 h-4" />
                            Navigate
                          </button>

                          {request.status === 'pending' && (
                            <button
                              onClick={() => onUpdateStatus(request.id, 'in_progress')}
                              className="bg-orange-500 hover:bg-orange-600 text-white px-4 py-2 rounded-lg text-sm font-semibold transition-colors"
                            >
                              Start Response
                            </button>
                          )}

                          {request.status === 'in_progress' && (
                            <button
                              onClick={() => onUpdateStatus(request.id, 'completed')}
                              className="bg-green-600 hover:bg-green-700 text-white px-4 py-2 rounded-lg text-sm font-semibold transition-colors"
                            >
                              Mark Complete
                            </button>
                          )}
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            ))
          )}
        </div>
      </div>
    </div>
  );
}

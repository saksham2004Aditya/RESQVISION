import { useState } from 'react';
import { AlertTriangle, Heart, Package, Users, Home, Plane, AlertCircle } from 'lucide-react';
import { EmergencyRequest, UrgencyLevel, HelpType, LocationData } from '../types';

interface EmergencyFormProps {
  photoData: string;
  location: LocationData;
  onSubmit: (request: Omit<EmergencyRequest, 'id' | 'createdAt' | 'updatedAt' | 'status'>) => void;
  onCancel: () => void;
}

const helpTypeOptions: { value: HelpType; label: string; icon: typeof Heart; color: string }[] = [
  { value: 'medical', label: 'Medical Emergency', icon: Heart, color: 'bg-red-500' },
  { value: 'rescue', label: 'Rescue Needed', icon: AlertCircle, color: 'bg-orange-500' },
  { value: 'supplies', label: 'Supplies Needed', icon: Package, color: 'bg-blue-500' },
  { value: 'shelter', label: 'Shelter Required', icon: Home, color: 'bg-green-500' },
  { value: 'evacuation', label: 'Evacuation', icon: Plane, color: 'bg-purple-500' },
  { value: 'body_recovery', label: 'Body Recovery', icon: Users, color: 'bg-gray-700' }
];

const urgencyOptions: { value: UrgencyLevel; label: string; color: string; description: string }[] = [
  { value: 'urgent', label: 'URGENT', color: 'bg-red-600 hover:bg-red-700', description: 'Life-threatening, immediate response required' },
  { value: 'moderate', label: 'MODERATE', color: 'bg-orange-500 hover:bg-orange-600', description: 'Serious situation, quick response needed' },
  { value: 'low', label: 'LOW', color: 'bg-yellow-500 hover:bg-yellow-600', description: 'Stable situation, can wait for response' }
];

export default function EmergencyForm({ photoData, location, onSubmit, onCancel }: EmergencyFormProps) {
  const [urgencyLevel, setUrgencyLevel] = useState<UrgencyLevel>('urgent');
  const [helpType, setHelpType] = useState<HelpType>('medical');
  const [description, setDescription] = useState('');
  const [volunteerContact, setVolunteerContact] = useState('');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();

    const request: Omit<EmergencyRequest, 'id' | 'createdAt' | 'updatedAt' | 'status'> = {
      photoUrl: photoData,
      latitude: location.latitude,
      longitude: location.longitude,
      locationAddress: location.address,
      urgencyLevel,
      helpType,
      description,
      volunteerContact: volunteerContact || undefined
    };

    onSubmit(request);
  };

  return (
    <div className="bg-white rounded-lg shadow-xl max-w-4xl w-full max-h-[90vh] overflow-y-auto">
      <div className="sticky top-0 bg-gradient-to-r from-red-600 to-red-700 text-white px-6 py-4 z-10">
        <h2 className="text-2xl font-bold flex items-center gap-2">
          <AlertTriangle className="w-7 h-7" />
          Emergency Request Form
        </h2>
        <p className="text-red-100 mt-1">Complete this form to dispatch help immediately</p>
      </div>

      <form onSubmit={handleSubmit} className="p-6 space-y-6">
        <div className="grid md:grid-cols-2 gap-6">
          <div className="space-y-2">
            <h3 className="font-semibold text-gray-700 text-sm uppercase tracking-wide">Captured Photo</h3>
            <img src={photoData} alt="Emergency location" className="w-full rounded-lg border-2 border-gray-200 shadow-md" />
            <div className="bg-gray-50 p-3 rounded-lg text-sm">
              <p className="text-gray-600 font-medium">Location Coordinates:</p>
              <p className="text-gray-900 font-mono">{location.latitude.toFixed(6)}, {location.longitude.toFixed(6)}</p>
              {location.address && (
                <>
                  <p className="text-gray-600 font-medium mt-2">Address:</p>
                  <p className="text-gray-900 text-xs">{location.address}</p>
                </>
              )}
            </div>
          </div>

          <div className="space-y-6">
            <div>
              <label className="block text-sm font-semibold text-gray-700 mb-3 uppercase tracking-wide">
                Urgency Level *
              </label>
              <div className="space-y-2">
                {urgencyOptions.map((option) => (
                  <button
                    key={option.value}
                    type="button"
                    onClick={() => setUrgencyLevel(option.value)}
                    className={`w-full text-left p-4 rounded-lg transition-all font-bold text-white ${option.color} ${
                      urgencyLevel === option.value ? 'ring-4 ring-offset-2 ring-gray-400 scale-105' : 'opacity-75'
                    }`}
                  >
                    <div className="flex items-center justify-between">
                      <span className="text-lg">{option.label}</span>
                      {urgencyLevel === option.value && <span className="text-2xl">✓</span>}
                    </div>
                    <p className="text-sm text-white text-opacity-90 mt-1">{option.description}</p>
                  </button>
                ))}
              </div>
            </div>

            <div>
              <label className="block text-sm font-semibold text-gray-700 mb-3 uppercase tracking-wide">
                Type of Help Needed *
              </label>
              <div className="grid grid-cols-2 gap-2">
                {helpTypeOptions.map((option) => {
                  const Icon = option.icon;
                  return (
                    <button
                      key={option.value}
                      type="button"
                      onClick={() => setHelpType(option.value)}
                      className={`p-3 rounded-lg transition-all border-2 ${
                        helpType === option.value
                          ? `${option.color} text-white border-transparent scale-105 shadow-lg`
                          : 'bg-white text-gray-700 border-gray-300 hover:border-gray-400'
                      }`}
                    >
                      <Icon className="w-6 h-6 mx-auto mb-1" />
                      <span className="text-xs font-semibold block">{option.label}</span>
                    </button>
                  );
                })}
              </div>
            </div>
          </div>
        </div>

        <div>
          <label className="block text-sm font-semibold text-gray-700 mb-2 uppercase tracking-wide">
            Additional Description
          </label>
          <textarea
            value={description}
            onChange={(e) => setDescription(e.target.value)}
            placeholder="Describe the situation: number of people affected, injuries, immediate dangers, etc."
            className="w-full px-4 py-3 border-2 border-gray-300 rounded-lg focus:border-red-500 focus:ring-2 focus:ring-red-200 outline-none resize-none transition-colors"
            rows={4}
          />
        </div>

        <div>
          <label className="block text-sm font-semibold text-gray-700 mb-2 uppercase tracking-wide">
            Volunteer Contact (Optional)
          </label>
          <input
            type="text"
            value={volunteerContact}
            onChange={(e) => setVolunteerContact(e.target.value)}
            placeholder="Phone number or identifier (optional)"
            className="w-full px-4 py-3 border-2 border-gray-300 rounded-lg focus:border-red-500 focus:ring-2 focus:ring-red-200 outline-none transition-colors"
          />
        </div>

        <div className="flex gap-4 pt-4">
          <button
            type="button"
            onClick={onCancel}
            className="flex-1 bg-gray-200 hover:bg-gray-300 text-gray-800 font-bold py-4 px-6 rounded-lg transition-colors"
          >
            Cancel
          </button>
          <button
            type="submit"
            className="flex-1 bg-red-600 hover:bg-red-700 text-white font-bold py-4 px-6 rounded-lg transition-colors shadow-lg"
          >
            Submit Emergency Request
          </button>
        </div>
      </form>
    </div>
  );
}

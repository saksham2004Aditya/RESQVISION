export type UrgencyLevel = 'urgent' | 'moderate' | 'low';

export type HelpType = 'medical' | 'rescue' | 'supplies' | 'body_recovery' | 'shelter' | 'evacuation';

export type RequestStatus = 'pending' | 'in_progress' | 'completed';

export interface EmergencyRequest {
  id: string;
  photoUrl?: string;
  latitude: number;
  longitude: number;
  locationAddress?: string;
  urgencyLevel: UrgencyLevel;
  helpType: HelpType;
  description: string;
  status: RequestStatus;
  volunteerContact?: string;
  createdAt: Date;
  updatedAt: Date;
  respondedBy?: string;
  responseTime?: Date;
  distance?: number;
}

export interface LocationData {
  latitude: number;
  longitude: number;
  accuracy: number;
  address?: string;
}
